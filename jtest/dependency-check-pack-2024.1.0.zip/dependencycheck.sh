#!/bin/bash

# Parameters:
#    -Dsettings=
#    -Dconfig= (Optional)
#    -Dsource.dir=
#    -Dresults.file=

export ANALYZER_HOME=`dirname $0`
echo ""
echo "Starting..."
echo ""

# Parameters:
#    -Dsettings=
#    -Dconfig= (Optional)
#    -Dsource.dir=
#    -Dresults.file=
#    -Dparasoft.local.storage.dir=reports/logs

# export JAVA_HOME=
if [ "x$JAVA_HOME" == "x" ]; then
	echo "JAVA_HOME environment variable is not set. Please make sure JAVA_HOME is set to Java 11"
	exit 1
fi
if [ ! -x "$JAVA_HOME/bin/java" ];  then
	echo "JAVA_HOME environment variable set incorrectly. Please make sure JAVA_HOME is set to Java 11"
	exit 1
fi

paramsWithD=' '
wasParameterUpdated='false'

# iterate every parameters (only settings, results.file or encodepass), which user write, to add '-D' prefix and '=' to suffix
# and splice them to one string (ex. "-Dresults.file=resultsFile") named "paramsWithD"
# after it "wasParameterUpdated" variable is change to true in order that avoiding double check on one parameter
# if parameter has got prefix '-D' tool add only '=' to suffix
# if parameter doesn't match settings, results.file or encodepass, it is spliced to string "paramsWithD" without any suffix or prefix
for var in "$@"
	do
		if [[ $var == "-settings" ]]; then
			paramsWithD="$paramsWithD"' -Dsettings='
			wasParameterUpdated='true'
		fi
		if [[ $var == "-results.file" ]]; then
			paramsWithD="$paramsWithD"' -Dresults.file='
			wasParameterUpdated='true'
		fi
		if [[ $var == "-encodepass" ]]; then
			paramsWithD="$paramsWithD"' -Dencodepass='
			wasParameterUpdated='true'
		fi
		if [[ $var == "-D"* ]]; then
			paramsWithD="$paramsWithD"' '"$var"
			wasParameterUpdated='true'
		fi
		if [[ $wasParameterUpdated == "false" ]]; then
			paramsWithD="$paramsWithD""$var"
		fi
		wasParameterUpdated='false'
	done

"$JAVA_HOME/bin/java" \
 -Djava.awt.headless=true -Dfelix.config.properties="file:etc/configFelix/config.properties" \
 -Dparasoft.diagnostics.off=true -Dparasoft.analyzer.home="$ANALYZER_HOME" \
 -Dfelix.fileinstall.dir="$ANALYZER_HOME/plugins/builtin/plugins","$ANALYZER_HOME/extensions" \
 -DisMultiLanguagePackMode=true \
 -Dtool="dependencycheck" \
 -Dcom.parasoft.xtest.controller.strategic.displayName="Dependency Check" \
 -Dorg.apache.commons.logging.Log=org.apache.commons.logging.impl.SimpleLog \
 -Dosgi.console.enable.builtin=true \
 -Dparasoft.local.storage.dir="$ANALYZER_HOME/.mlp" \
 $paramsWithD \
 -jar "$ANALYZER_HOME/bin/org.apache.felix.main-7.0.5.jar" org.apache.felix.main.Main \
 -data "$ANALYZER_HOME/.xtest"